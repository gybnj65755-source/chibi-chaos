# CHIBI CHAOS · v0.1

L’île des Miettes est un petit royaume jouable dans Safari. Le jeu utilise Phaser 3, TypeScript et Vite. L’île, les bâtiments et le promeneur sont dessinés dans Phaser à partir de formes originales.

## Jouer sur iPhone

Ouvre le lien du jeu dans Safari et tourne l’iPhone en paysage pour afficher la carte entre la liste des bâtiments et la fiche de sélection.

- Touche un bâtiment sur l’île ou son nom dans la liste. Glisse le doigt sur la carte pour déplacer la caméra. Les commandes **−**, **+** et **⌖** ajustent la vue.
- Essaie **Scierie → Améliorer**. Le premier niveau prend 12 secondes. Le jeu déduit le bois, la pierre, le fer et l’or au lancement.
- Touche **Déplacer**, puis une case dorée marquée d’un **+**. Les cases occupées sont exclues. **Annuler** ferme le mode déplacement.
- La maison royale produit de l’or et les trois ateliers produisent leurs ressources toutes les 60 secondes. **Récolter** transfère le stock d’un bâtiment vers la réserve commune, jusqu’à la capacité de l’entrepôt. Le surplus attend la prochaine récolte.
- La production couvre jusqu’à huit heures d’absence. Les améliorations se terminent à leur échéance. La même adresse Safari retrouve la partie via le stockage local. Une autre adresse, un autre navigateur ou l’effacement des données du site donne une partie distincte.

## Enregistrer le projet dans GitHub depuis l’iPhone

1. Télécharge et décompresse l’archive source dans l’app **Fichiers**. Un appui sur un ZIP dans Fichiers l’extrait.
2. Dans Safari, crée un dépôt sur [github.com/new](https://github.com/new). Tu peux choisir un dépôt privé. Coche **Add a README file** pour initialiser la branche par défaut.
3. Sur la page du dépôt, utilise **Add file → Upload files** pour les fichiers racine, dont `package.json`, `package-lock.json`, `index.html`, `tsconfig.json` et `netlify.toml`. Valide avec **Commit changes**. Tu peux conserver le README que GitHub a initialisé ou le remplacer par celui de l’archive.
4. Si le sélecteur d’iOS ne permet pas d’envoyer le dossier entier, utilise **Add file → Create new file** pour chaque fichier de `src/`. Saisis son chemin complet, par exemple `src/catalog.ts`, puis colle le contenu depuis Fichiers et valide avec **Commit changes**. GitHub crée le dossier à partir du chemin. Ajoute les cinq fichiers TypeScript et la feuille CSS de cette manière.
5. Pour modifier un fichier ensuite, ouvre-le dans GitHub et touche le crayon, puis **Commit changes**. Si une commande est masquée sur iPhone, demande la version pour ordinateur dans Safari.

## Publier sur Netlify depuis l’iPhone

1. Connecte-toi à [app.netlify.com](https://app.netlify.com/) dans Safari et choisis **Add new project → Import an existing project**.
2. Choisis **GitHub**, autorise Netlify à lire le dépôt et sélectionne-le. Pour un dépôt contenant uniquement le contenu de l’archive, laisse **Base directory** vide.
3. La configuration fournie utilise `npm run build` et publie `dist` avec Node 22. Vérifie ces deux champs dans Netlify et lance **Deploy**.
4. Ouvre l’adresse `*.netlify.app` du projet. Après chaque commit sur la branche de production, Netlify reconstruit le jeu. La partie reste liée à l’adresse du site.

## Structure du projet

| Fichier | Responsabilité |
| --- | --- |
| `src/catalog.ts` | Types de bâtiments, ressources, grille, niveaux et courbes de progression |
| `src/realm.ts` | Règles du royaume et format de sauvegarde, indépendants de Phaser |
| `src/KingdomScene.ts` | Carte Phaser, caméra, sélection et placement |
| `src/art.ts` | Graphismes isométriques procéduraux |
| `src/main.ts` | Interface, liaison avec Phaser et stockage local |
| `src/style.css` | Mise en page tactile et zones de sécurité |

Les héros, invocations, combats et quêtes pourront avoir leurs propres catalogues et scènes. L’économie et le format versionné permettent de les raccorder au royaume.

Pour vérifier le projet dans un environnement Node 22.12 ou ultérieur, exécute `npm install`, puis `npm run build`. Le serveur de développement se lance avec `npm run dev`.
